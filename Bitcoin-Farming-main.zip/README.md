# Bitcoin-Farming
 an idle-click bitcoin farming game (maintaining)
